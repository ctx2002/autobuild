use this command to show all certs
sudo /opt/puppetlabs/bin/puppetserver ca list

restart server

sudo systemctl restart puppetserver

Make Puppet master and agents are able to communicate

we need to pdate /etc/hosts file on each master and client server.

1> on master server, open /etc/hosts file, and load clients ip to it.

192.168.33.11    agent1.example.com agent1
192.168.33.12    agent2.example.com agent2
192.168.33.13    agent3.example.com agent3


2> on each client server, open /etc/hosts file, and load master's ip to it

192.168.33.30    master.example.com master

From the command line on each Puppet agent, run puppet agent -t
From your Puppet master, run puppetserver ca list and then puppetserver ca sign <AGENT NAME> to sign the certificates of your Puppet agents


https://www.puppetcookbook.com

find out config dir path
puppet config print --section master confdir