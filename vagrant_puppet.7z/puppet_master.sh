#!/bin/bash
#args:
#     $1 - ip address of master puppet server.
# Run on VM to bootstrap Puppet Master server
. /vagrant/scripts/func.sh
#set up time zone
timedatectl set-timezone Pacific/Auckland

is_process_running "puppetserver"
res="$?"
if [ "$res" -eq 0 ]
then
    echo "Puppet Master is already installed. Exiting..."
else
    # Install Puppet Master
	echo "\n" >> ~/.bashrc
	echo 'export PATH=/opt/puppetlabs/bin:$PATH' >> ~/.bashrc

    wget https://apt.puppetlabs.com/puppet6-release-bionic.deb
    dpkg -i puppet6-release-bionic.deb
    apt-get update -yq
    apt-get install puppetserver -yq

	/opt/puppetlabs/bin/puppetserver ca setup
	apt-get install net-tools -yq
	apt-get install ntp -yq
	apt-get install -y pkg-config

    # Configure /etc/hosts file

    echo "# Host config for Puppet Master and Agent Nodes" | tee --append /etc/hosts 2> /dev/null
	
	append_to_file "/etc/hosts" "$@"
    # Install some initial puppet modules on Puppet Master server
    
    /opt/puppetlabs/bin/puppet module install puppetlabs-ntp
    /opt/puppetlabs/bin/puppet module install puppetlabs-git
    /opt/puppetlabs/bin/puppet module install puppetlabs-vcsrepo
    /opt/puppetlabs/bin/puppet module install puppet/php
    /opt/puppetlabs/bin/puppet module install puppet/nginx
    /opt/puppetlabs/bin/puppet module install puppetlabs/mysql
    apt-get install vim -yq

    #mkdir -p /etc/puppetlabs/code/environments/production/manifests
	
	cp /vagrant/scripts/puppet.conf /etc/puppetlabs/puppet/puppet.conf
	#cp /vagrant/scripts/autosign.conf /etc/puppetlabs/puppet/autosign.conf
	cp /vagrant/scripts/puppetserver /etc/default/puppetserver
	systemctl restart puppetserver	
fi
#define node
cp /vagrant/scripts/site.pp /etc/puppetlabs/code/environments/production/manifests/site.pp

    