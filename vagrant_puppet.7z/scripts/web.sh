#!/bin/sh

# Run on VM to bootstrap Puppet Agent nodes
. /vagrant/scripts/func.sh

is_process_running "puppet agent"
res="$?"
if [ "$res" -eq 0 ]
then
    echo "Puppet Agent is already installed. Moving on..."
fi

if cat crontab -u root -l | grep puppet 2> /dev/null
then
    echo "Puppet Agent is already configured. Exiting..."
else
    timedatectl set-timezone Pacific/Auckland
	echo "\n" >> ~/.bashrc
	echo 'export PATH=/opt/puppetlabs/bin:$PATH' >> ~/.bashrc
	
    wget https://apt.puppetlabs.com/puppet6-release-bionic.deb
	dpkg -i puppet6-release-bionic.deb
    apt-get update -yq
	apt-get install puppet-agent
	
	apt-get install vim -yq
	apt-get install net-tools -yq
	
	
	
    /opt/puppetlabs/bin/puppet resource cron puppet-agent ensure=present user=root minute=30 \
        command='/opt/puppetlabs/bin/puppet agent --onetime --no-daemonize --splay'

    /opt/puppetlabs/bin/puppet resource service puppet ensure=running enable=true

    # Configure /etc/hosts file
	append_to_file "/etc/hosts" "$@"

    # Add agent section to /etc/puppet/puppet.conf
    echo "" && echo "[agent]\nserver=puppet" | tee --append /etc/puppetlabs/puppet/puppet.conf 2> /dev/null

    puppet agent --enable
fi
