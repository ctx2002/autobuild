#!/bin/bash

#return : 0 mean true, 1 mean false
is_process_running()
{
    local comm='ps aux | grep "$1" | grep -v grep > /dev/null 2>&1'
    eval "$comm"
}
#usage:
#append_to_file "/etc/hosts" "192.168.7.1 web1" "192.168.7.2 web2"
#or in side an other script, we take all argument from command line
#    append_to_file "$@"
append_to_file()
{
    local name="$1"
    shift
	
    for var in "$@"
	do
		echo "$var" | tee --append "$name" > /dev/null 2>&1
	done    
}